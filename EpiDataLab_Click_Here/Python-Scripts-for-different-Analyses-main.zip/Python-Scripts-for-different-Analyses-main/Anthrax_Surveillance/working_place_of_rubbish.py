import geopandas as gpd
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import contextily as ctx
from libpysal.weights import Queen, KNN
from libpysal.weights.util import attach_islands
from esda import getisord

# Load shapefile and Excel data
gdf = gpd.read_file("C:/Users/Administrator/Desktop/uganda_districts.shp")
df = pd.read_excel("D:/EVD_Mbale/Vero/anthrax_pythonanalysis.xlsx")

# Clean merge keys
gdf["DIST_UP"] = gdf["District"].astype(str).str.upper().str.replace(r'\W+', '', regex=True)
df["DIST_UP"] = df["District"].astype(str).str.upper().str.replace(r'\W+', '', regex=True)

# Merge spatial and statistical data
merged = gdf.merge(df, on="DIST_UP", how="left")
merged = merged.dropna(subset=["Total_case_counts", "Incidencerate", "Positivity_Rate"], how="all")
merged = merged.to_crs(epsg=32636)


# Build spatial weights
wq = Queen.from_dataframe(merged, use_index=False)
coords = np.column_stack((merged.geometry.centroid.x, merged.geometry.centroid.y))
knn = KNN.from_array(coords, k=3)
w = attach_islands(wq, knn)
w.transform = 'r'

# Define Getis-Ord Gi* computation
def compute_gi(values):
    clean_vals = np.nan_to_num(values).astype(float)
    return getisord.G_Local(clean_vals, w, permutations=999).Zs

# Compute Z-scores
merged["Gi_Total_Z"] = compute_gi(merged["Total_case_counts"])
merged["Gi_Incid_Z"] = compute_gi(merged["Incidencerate"])
merged["Gi_Pos_Z"] = compute_gi(merged["Positivity_Rate"])

# Categorize hotspots/coldspots
def categorize(z):
    if z >= 2.58:
        return "Hotspot (p ≤ 0.01)"
    elif z >= 1.96:
        return "Hotspot (p ≤ 0.05)"
    elif z <= -2.58:
        return "Coldspot (p ≤ 0.01)"
    elif z <= -1.96:
        return "Coldspot (p ≤ 0.05)"
    else:
        return "Not Significant"

merged["Gi_Total_Cat"] = merged["Gi_Total_Z"].apply(categorize)
merged["Gi_Incid_Cat"] = merged["Gi_Incid_Z"].apply(categorize)
merged["Gi_Pos_Cat"] = merged["Gi_Pos_Z"].apply(categorize)

# Color scheme
color_dict = {
    "Hotspot (p ≤ 0.01)": "#FF0000",
    "Hotspot (p ≤ 0.05)": "#FFA500",
    "Coldspot (p ≤ 0.01)": "#0000FF",
    "Coldspot (p ≤ 0.05)": "#87CEFA",
    "Not Significant": "#D3D3D3"
}

# Plotting function
def plot_hotspots(column, title):
    fig, ax = plt.subplots(figsize=(10, 10))
    merged.plot(
        column=column,
        cmap=mcolors.ListedColormap([color_dict[c] for c in color_dict.keys()]),
        categorical=True,
        legend=True,
        legend_kwds={'title': 'Cluster Type'},
        ax=ax,
        edgecolor='black',
        linewidth=0.3
    )
    ctx.add_basemap(ax, crs=merged.crs.to_string(), source=ctx.providers.OpenStreetMap.Mapnik)
    ax.set_title(title, fontsize=15)
    ax.axis('off')
    plt.tight_layout()
    plt.show()

# Plot maps
plot_hotspots("Gi_Total_Cat", "Anthrax Hotspots: Total Case Counts")
plot_hotspots("Gi_Incid_Cat", "Anthrax Hotspots: Incidence Rate")
plot_hotspots("Gi_Pos_Cat", "Anthrax Hotspots: Positivity Rate")

samples = merged[merged['Total_case_counts'] >= 10 ]  # e.g. threshold=10
print(samples[['District', 'Total_case_counts', 'Gi_Total_Z', 'Gi_Total_Cat']])

