import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

# Set Times New Roman globally
plt.rcParams["font.family"] = "Times New Roman"

# === Data Setup ===
data = {
    "Date": [
        "26-Nov-23", "01-Dec-23", "06-Dec-23", "14-Dec-23", "18-Dec-23",
        "20-Dec-23", "22-Dec-23", "26-Dec-23", "27-Dec-23", "31-Dec-23",
        "06-Jan-24", "20-Jan-24", "08-Feb-24", "15-Feb-24", "29-Feb-24",
        "13-Mar-24", "17-Mar-24", "21-Mar-24", "28-Mar-24", "04-Jun-24",
        "10-Jun-24", "16-Jun-24", "16-Aug-24", "15-Sep-24", "16-Sep-24",
        "26-Sep-24", "27-Sep-24", "07-Oct-24", "08-Oct-24", "21-Oct-24",
        "31-Oct-24", "05-Nov-24", "06-Nov-24", "10-Nov-24", "15-Nov-24",
        "26-Nov-24", "04-Dec-24", "10-Dec-24", "13-Dec-24", "17-Dec-24",
        "20-Dec-24", "24-Dec-24", "09-Jan-25", "11-Jan-25", "20-Jan-25",
        "14-Feb-25", "28-Feb-25", "05-Mar-25", "30-Mar-25", "04-Apr-25",
        "10-Apr-25"
    ],
    "Cases": [
        3, 1, 3, 1, 2, 1, 2, 1, 1, 1,
        2, 1, 1, 3, 1, 2, 1, 4, 1, 1,
        2, 4, 2, 1, 2, 1, 2, 1, 1, 1,
        2, 2, 2, 3, 2, 1, 1, 3, 2, 4,
        8, 1, 2, 5, 2, 2, 2, 1, 1, 1,
        4
    ]
}

# === DataFrame Prep ===
df = pd.DataFrame(data)
df["Date"] = pd.to_datetime(df["Date"], format="%d-%b-%y")
df["Month"] = df["Date"].dt.strftime("%b")     # Short month names
df["Month_Num"] = df["Date"].dt.month          # Numerical month for sorting

# Sort by month number for correct calendar order
df = df.sort_values("Month_Num")

# === Plotting ===
plt.figure(figsize=(14, 7))

# Boxplot
sns.boxplot(data=df, x="Month", y="Cases", hue="Month", palette="Blues", dodge=False, legend=False)

# Title and axis labels
plt.title("Seasonality of Confirmed Anthrax Cases in Uganda,\n(Nov 2023 to Apr 2025).",
          fontsize=30, fontweight="bold")

plt.xlabel("Month of Diagnosis", fontsize=25, fontweight="bold")
plt.ylabel("Number of Cases", fontsize=25, fontweight="bold")

# Tick label font sizes
plt.xticks(fontsize=23, fontweight="bold")
plt.yticks(fontsize=23, fontweight="bold")

# Grid and layout
plt.grid(axis="y", linestyle="--", color="lightgrey")
plt.tight_layout()
plt.show()
