import geopandas as gpd
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import contextily as ctx
from libpysal.weights import Queen, KNN
from libpysal.weights.util import attach_islands
from esda import moran

# 1. Load data
gdf = gpd.read_file("C:/Users/Administrator/Desktop/uganda_districts.shp")
df = pd.read_excel("D:/EVD_Mbale/Vero/anthrax_pythonanalysis.xlsx")

# 2. Clean for merging
gdf["DIST_UP"] = gdf["District"].str.upper().str.replace(r'\W+', '', regex=True)
df["DIST_UP"] = df["District"].str.upper().str.replace(r'\W+', '', regex=True)

# 3. Merge datasets
merged = gdf.merge(df, on="DIST_UP", how="left")
merged = merged.dropna(subset=["Total_case_counts", "Incidencerate", "Positivity_Rate"], how="all")
merged = merged.to_crs(epsg=32636)

# 4. Compute spatial weights
wq = Queen.from_dataframe(merged, use_index=False)
coords = np.column_stack((merged.geometry.centroid.x, merged.geometry.centroid.y))
knn = KNN.from_array(coords, k=3)
w = attach_islands(wq, knn)
w.transform = 'r'

# 5. Identify disconnected districts
disconnected_ids = w.islands
disconnected = merged.iloc[disconnected_ids] if disconnected_ids else gpd.GeoDataFrame()

# 6. Plot disconnected districts
fig, ax = plt.subplots(figsize=(10, 10))
merged.boundary.plot(ax=ax, color="black", linewidth=0.5)
merged.plot(ax=ax, facecolor="lightgray", edgecolor="black")
if not disconnected.empty:
    disconnected.plot(ax=ax, color="red", edgecolor="black", linewidth=1, label="Disconnected (red)")
ctx.add_basemap(ax, crs=merged.crs.to_string(), source=ctx.providers.OpenStreetMap.Mapnik)
ax.set_title("Map of Uganda Districts — Highlighting Disconnected Units", fontsize=14)
ax.axis('off')
plt.legend()
plt.tight_layout()
plt.show()

# 7. Compute Global Moran's I
print("\n*** Global Moran's I:")
print("Total_case_counts:", moran.Moran(merged["Total_case_counts"].fillna(0).values, w).I)
print("Incidencerate:", moran.Moran(merged["Incidencerate"].fillna(0).values, w).I)
print("Positivity_Rate:", moran.Moran(merged["Positivity_Rate"].fillna(0).values, w).I)
