import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.ticker import MaxNLocator

# Set Times New Roman globally
plt.rcParams["font.family"] = "Times New Roman"

# === Data Setup ===
data = {
    "Date": [
        "26-Nov-23", "01-Dec-23", "06-Dec-23", "14-Dec-23", "18-Dec-23",
        "20-Dec-23", "22-Dec-23", "26-Dec-23", "27-Dec-23", "31-Dec-23",
        "06-Jan-24", "20-Jan-24", "08-Feb-24", "15-Feb-24", "29-Feb-24",
        "13-Mar-24", "17-Mar-24", "21-Mar-24", "28-Mar-24", "04-Jun-24",
        "10-Jun-24", "16-Jun-24", "16-Aug-24", "15-Sep-24", "16-Sep-24",
        "26-Sep-24", "27-Sep-24", "07-Oct-24", "08-Oct-24", "21-Oct-24",
        "31-Oct-24", "05-Nov-24", "06-Nov-24", "10-Nov-24", "15-Nov-24",
        "26-Nov-24", "04-Dec-24", "10-Dec-24", "13-Dec-24", "17-Dec-24",
        "20-Dec-24", "24-Dec-24", "09-Jan-25", "11-Jan-25", "20-Jan-25",
        "14-Feb-25", "28-Feb-25", "05-Mar-25", "30-Mar-25", "04-Apr-25",
        "10-Apr-25"
    ],
    "Cases": [
        3, 1, 3, 1, 2, 1, 2, 1, 1, 1,
        2, 1, 1, 3, 1, 2, 1, 4, 1, 1,
        2, 4, 2, 1, 2, 1, 2, 1, 1, 1,
        2, 2, 2, 3, 2, 1, 1, 3, 2, 4,
        8, 1, 2, 5, 2, 2, 2, 1, 1, 1,
        4
    ]
}

df = pd.DataFrame(data)
df["Date"] = pd.to_datetime(df["Date"], format="%d-%b-%y")
df["Year"] = df["Date"].dt.year
df["Month-Day"] = df["Date"].dt.strftime("%d-%b")

# === Expand to Full Timeline for Each Year ===
full_range = pd.date_range("2023-11-22", "2025-04-17", freq="D")
df_full = df.set_index("Date").reindex(full_range, fill_value=0).rename_axis("Date").reset_index()
df_full["Year"] = df_full["Date"].dt.year
df_full["Month-Day"] = df_full["Date"].dt.strftime("%d-%b")

# === Rolling average per year ===
df_full["Rolling"] = df_full.groupby("Year")["Cases"].transform(lambda x: x.rolling(window=14, center=True).mean())

# Pivot to "Month-Day" vs Year matrix
df_smoothed = df_full.pivot_table(index="Month-Day", columns="Year", values="Rolling", aggfunc="mean")

# Keep calendar order
df_smoothed = df_smoothed.reindex(pd.date_range("2024-01-01", "2024-12-31").strftime("%d-%b").unique(), fill_value=0)

# === Plotting ===
fig, ax = plt.subplots(figsize=(16, 8))

colors = {
    2023: "#4B0082",   # Indigo
    2024: "#2E8B57",   # Sea Green
    2025: "#DC143C"    # Crimson
}


for year in df_smoothed.columns:
    ax.plot(
        df_smoothed.index,
        df_smoothed[year],
        label=f"{year}",
        linewidth=3,
        color=colors.get(year, "gray")
    )

# Axis and labels
ax.set_xticks(df_smoothed.index[::15])
ax.set_xticklabels(df_smoothed.index[::15], rotation=80, fontsize=16)

ax.set_title("Comparing intra annual trends of Human Anthrax across 2023 to 2025, Uganda.", fontsize=24, fontweight="bold")
ax.set_xlabel("Day and Month of Diagnosis", fontsize=18, fontweight="bold")
ax.set_ylabel("14-Day Smoothed Case Count", fontsize=18, fontweight="bold")
ax.yaxis.set_major_locator(MaxNLocator(integer=True))

# Styling
ax.grid(axis="y", linestyle="--", color="lightgrey")
ax.set_facecolor("white")
fig.patch.set_facecolor("white")
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
ax.legend(title="Year", fontsize=12, title_fontsize=14)

fig.tight_layout()
plt.show()
