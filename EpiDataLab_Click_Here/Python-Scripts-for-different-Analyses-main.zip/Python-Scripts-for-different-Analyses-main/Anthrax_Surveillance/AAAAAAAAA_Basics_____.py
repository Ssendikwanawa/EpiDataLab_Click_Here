import geopandas as gpd
import pandas as pd

# Load the shapefile
shp_path = "C:/Users/Administrator/Desktop/uganda_districts.shp"
gdf = gpd.read_file(shp_path)

# Create a DataFrame with the 'District' column and a placeholder 'Total_case_counts' column
export_df = gdf[['District']].copy()
export_df['Total_case_counts'] = 0  # Placeholder for manual entry

# Export to Excel
export_df.to_excel("C:/Users/Administrator/Desktop/districts_for_cleaning.xlsx", index=False)

# Print to console
print(export_df.head())

# Exit to prevent further code execution
exit()


import geopandas as gpd
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import contextily as ctx
from libpysal.weights import Queen, KNN
from libpysal.weights.util import attach_islands
from esda import moran, getisord

# 1. Load datasets
shapefile = "C:/Users/Administrator/Desktop/uganda_districts.shp"
excel_data = "D:/EVD_Mbale/Vero/anthrax_pythonanalysis.xlsx"

gdf = gpd.read_file(shapefile)
df = pd.read_excel(excel_data)

# 2. Preprocess for merge
gdf["DISTRICT_CLEAN"] = gdf["District"].astype(str).str.upper().str.replace(r'\W+', '', regex=True)
df["DISTRICT_CLEAN"] = df["District"].astype(str).str.upper().str.replace(r'\W+', '', regex=True)

# 3. Merge spatial and statistical data
merged = gdf.merge(df, on="DISTRICT_CLEAN", how="left")

# 4. Ensure projection for analysis and basemaps
merged = merged.to_crs(epsg=32636)

# 5. Build spatial weights with Queen and backup KNN
wq = Queen.from_dataframe(merged, use_index=False)
coords = np.column_stack((merged.geometry.centroid.x, merged.geometry.centroid.y))
knn = KNN.from_array(coords, k=3)  # safer with k=3
w = attach_islands(wq, knn)
w.transform = 'r'

# 6. Compute Global Moran's I
print("\n*** Global Moran's I:")
print("Total Cases:", moran.Moran(merged['Total_case_counts'].fillna(0).values, w).I)
print("Incidence Rate:", moran.Moran(merged['Incidencerate'].fillna(0).values, w).I)
print("Positivity Rate:", moran.Moran(merged['Positivity_Rate'].fillna(0).values, w).I)

# 7. Compute Local Getis-Ord Gi*
def compute_gi(values):
    clean_vals = np.nan_to_num(values).astype(float)  # ensure all inputs are float64
    return getisord.G_Local(clean_vals, w, permutations=999).Zs

# 8. Categorize Gi* results
def label_gi(z):
    if z >= 2.58:
        return "Hotspot (p ≤ 0.01)"
    elif 1.96 <= z < 2.58:
        return "Hotspot (p ≤ 0.05)"
    elif -2.58 <= z < -1.96:
        return "Coldspot (p ≤ 0.05)"
    elif z <= -2.58:
        return "Coldspot (p ≤ 0.01)"
    else:
        return "Not significant"

# Apply Gi* computations
merged['Gi_Total_Z'] = compute_gi(merged['Total_case_counts'])
merged['Gi_Inc_Z'] = compute_gi(merged['Incidencerate'])
merged['Gi_Pos_Z'] = compute_gi(merged['Positivity_Rate'])

# Categorize Gi* Z-scores
merged['Gi_Total_cat'] = merged['Gi_Total_Z'].apply(label_gi)
merged['Gi_Inc_cat'] = merged['Gi_Inc_Z'].apply(label_gi)
merged['Gi_Pos_cat'] = merged['Gi_Pos_Z'].apply(label_gi)


merged['Gi_Total_Z'] = compute_gi(merged['Total_case_counts'])
merged['Gi_Inc_Z'] = compute_gi(merged['Incidencerate'])
merged['Gi_Pos_Z'] = compute_gi(merged['Positivity_Rate'])

# 8. Categorization Function
def label_gi(z):
    if z >= 2.58:
        return "Hotspot (p ≤ 0.01)"
    elif 1.96 <= z < 2.58:
        return "Hotspot (p ≤ 0.05)"
    elif -2.58 <= z < -1.96:
        return "Coldspot (p ≤ 0.05)"
    elif z <= -2.58:
        return "Coldspot (p ≤ 0.01)"
    else:
        return "Not significant"

for col in ['Gi_Total_Z', 'Gi_Inc_Z', 'Gi_Pos_Z']:
    cat_col = col.replace('_Z', '_cat')
    merged[cat_col] = merged[col].apply(label_gi)

# 9. Define colors
color_dict = {
    "Hotspot (p ≤ 0.01)": "#FF0000",
    "Hotspot (p ≤ 0.05)": "#ffb500",
    "Coldspot (p ≤ 0.05)": "#6baed5",
    "Coldspot (p ≤ 0.01)": "#084594",
    "Not significant": "#696969"
}

# 10. Plotting function
def plot_gi_map(column, title):
    fig, ax = plt.subplots(figsize=(10, 10))
    merged.plot(
        column=column,
        categorical=True,
        cmap=mcolors.ListedColormap([color_dict[c] for c in color_dict]),
        legend=True,
        legend_kwds={'title': "Cluster Type"},
        ax=ax,
        edgecolor='black',
        linewidth=0.5
    )
    ctx.add_basemap(ax, crs=merged.crs.to_string(), source=ctx.providers.OpenStreetMap.Mapnik)
    ax.set_title(title, fontsize=14)
    ax.axis('off')
    plt.tight_layout()
    plt.show()

# 11. Generate Maps
plot_gi_map('Gi_Total_cat', 'Anthrax Clusters by Total Case Counts')
plot_gi_map('Gi_Inc_cat', 'Anthrax Clusters by Incidence Rate')
plot_gi_map('Gi_Pos_cat', 'Anthrax Clusters by Positivity Rate')
