import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.ticker import MaxNLocator

# Set Times New Roman globally
plt.rcParams["font.family"] = "Times New Roman"

# === Data Setup ===
data = {
    "Date": [
        "26-Nov-23", "01-Dec-23", "06-Dec-23", "14-Dec-23", "18-Dec-23",
        "20-Dec-23", "22-Dec-23", "26-Dec-23", "27-Dec-23", "31-Dec-23",
        "06-Jan-24", "20-Jan-24", "08-Feb-24", "15-Feb-24", "29-Feb-24",
        "13-Mar-24", "17-Mar-24", "21-Mar-24", "28-Mar-24", "04-Jun-24",
        "10-Jun-24", "16-Jun-24", "16-Aug-24", "15-Sep-24", "16-Sep-24",
        "26-Sep-24", "27-Sep-24", "07-Oct-24", "08-Oct-24", "21-Oct-24",
        "31-Oct-24", "05-Nov-24", "06-Nov-24", "10-Nov-24", "15-Nov-24",
        "26-Nov-24", "04-Dec-24", "10-Dec-24", "13-Dec-24", "17-Dec-24",
        "20-Dec-24", "24-Dec-24", "09-Jan-25", "11-Jan-25", "20-Jan-25",
        "14-Feb-25", "28-Feb-25", "05-Mar-25", "30-Mar-25", "04-Apr-25",
        "10-Apr-25"
    ],
    "Cases": [
        3, 1, 3, 1, 2, 1, 2, 1, 1, 1,
        2, 1, 1, 3, 1, 2, 1, 4, 1, 1,
        2, 4, 2, 1, 2, 1, 2, 1, 1, 1,
        2, 2, 2, 3, 2, 1, 1, 3, 2, 4,
        8, 1, 2, 5, 2, 2, 2, 1, 1, 1,
        4
    ]
}

df = pd.DataFrame(data)

# Fix potential date parsing issues (e.g. 'Sept' -> 'Sep')
df["Date"] = pd.to_datetime(df["Date"], format="%d-%b-%y")

# === Fill in missing days ===
all_dates = pd.date_range(start="22-Nov-2023", end="17-Apr-2025", freq="D")
df_full = df.set_index("Date").reindex(all_dates, fill_value=0).reset_index()
df_full.columns = ["Date", "Cases"]

# === Optional: Rolling average (14-day window) ===
df_full["Rolling_Mean"] = df_full["Cases"].rolling(window=14, center=True).mean()

# === Plotting ===
# === Plotting ===
fig, ax = plt.subplots(figsize=(16, 8))

# Bars
ax.bar(df_full["Date"], df_full["Cases"], color="cadetblue", edgecolor="white", width=28, label="Daily Cases") ##199dba, #199

# Rolling mean
ax.plot(df_full["Date"], df_full["Rolling_Mean"], color="#FF0000", linewidth=4, label="14-Day Moving Avg")

# X-axis ticks every 14 days
step = 14
ax.set_xticks(df_full["Date"][::step])
ax.set_xticklabels(
    [d.strftime("%d-%b-%y") for d in df_full["Date"][::step]],
    rotation=80,
    fontsize=17
)

# Labels and title
ax.set_title("Human Anthrax Case Trends Over Time (Nov 2023 to Apr 2025), Uganda.", fontsize=23, fontweight="bold", color="#333")
ax.set_xlabel("Date of Diagnosis", fontsize=18, fontweight="bold")
ax.set_ylabel("No. of Confirmed Cases", fontsize=18, fontweight="bold")
ax.yaxis.set_major_locator(MaxNLocator(integer=True))

# Grid and background
ax.grid(axis="y", color="lightgrey", linestyle="--", zorder=1)
ax.set_facecolor("white")
fig.patch.set_facecolor("white")
ax.spines["top"].set_visible(False)
ax.spines["right"].set_visible(False)
ax.legend(fontsize=14, loc="upper left")

# === Tweak Axis Limits to Reduce Left Padding ===
buffer = pd.Timedelta(days=2)  # shrink buffer
ax.set_xlim(df_full["Date"].min() - buffer, df_full["Date"].max() + buffer)

# Optional: tighter layout
fig.tight_layout()
plt.show()

