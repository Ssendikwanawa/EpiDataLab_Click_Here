import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

# === Data Setup ===
data = {
    "Date": [
        "26-Nov-23", "01-Dec-23", "06-Dec-23", "14-Dec-23", "18-Dec-23",
        "20-Dec-23", "22-Dec-23", "26-Dec-23", "27-Dec-23", "31-Dec-23",
        "06-Jan-24", "20-Jan-24", "08-Feb-24", "15-Feb-24", "29-Feb-24",
        "13-Mar-24", "17-Mar-24", "21-Mar-24", "28-Mar-24", "04-Jun-24",
        "10-Jun-24", "16-Jun-24", "16-Aug-24", "15-Sep-24", "16-Sep-24",
        "26-Sep-24", "27-Sep-24", "07-Oct-24", "08-Oct-24", "21-Oct-24",
        "31-Oct-24", "05-Nov-24", "06-Nov-24", "10-Nov-24", "15-Nov-24",
        "26-Nov-24", "04-Dec-24", "10-Dec-24", "13-Dec-24", "17-Dec-24",
        "20-Dec-24", "24-Dec-24", "09-Jan-25", "11-Jan-25", "20-Jan-25",
        "14-Feb-25", "28-Feb-25", "05-Mar-25", "30-Mar-25", "04-Apr-25",
        "10-Apr-25"
    ],
    "Cases": [
        3, 1, 3, 1, 2, 1, 2, 1, 1, 1,
        2, 1, 1, 3, 1, 2, 1, 4, 1, 1,
        2, 4, 2, 1, 2, 1, 2, 1, 1, 1,
        2, 2, 2, 3, 2, 1, 1, 3, 2, 4,
        8, 1, 2, 5, 2, 2, 2, 1, 1, 1,
        4
    ]
}
df = pd.DataFrame(data)
df["Date"] = pd.to_datetime(df["Date"], format="%d-%b-%y")

# ========== Monthly Average Line Plot ==========
df["Month"] = df["Date"].dt.month_name()
monthly_avg = df.groupby(df["Date"].dt.month).agg(
    Month_Name=("Month", "first"),
    Avg_Cases=("Cases", "mean")
).sort_index()

plt.figure(figsize=(12, 6))
plt.plot(monthly_avg["Month_Name"], monthly_avg["Avg_Cases"], marker="o", color="#199dba", linewidth=3)
plt.title("Average Monthly Anthrax Cases in Uganda (2023–2025)", fontsize=18, fontweight="bold")
plt.xlabel("Month", fontsize=14)
plt.ylabel("Average Cases", fontsize=14)
plt.grid(axis="y", linestyle="--", color="lightgrey")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# ========== Grouped Bar Plot by Month and Year ==========
df["Month"] = df["Date"].dt.strftime("%b")
df["Year"] = df["Date"].dt.year
df["Month_Num"] = df["Date"].dt.month
df = df.sort_values(by=["Month_Num", "Year"])

plt.figure(figsize=(16, 7))
sns.barplot(data=df, x="Month", y="Cases", hue="Year", palette="Set2", dodge=True) # to disable the bars (sns.barplot(    data=df,     x="Month", y="Cases",    hue="Year",     estimator=sum,  # This disables averaging and CIs     ci=None,        # Hides confidence intervalspalette="Set2", dodge=True)

plt.title("Monthly Distribution of Anthrax Cases by Year", fontsize=18, fontweight="bold")
plt.xlabel("Month", fontsize=14)
plt.ylabel("Number of Cases", fontsize=14)
plt.legend(title="Year", fontsize=12, title_fontsize=13)
plt.grid(axis="y", linestyle="--", color="lightgrey")
plt.tight_layout()
plt.show()
