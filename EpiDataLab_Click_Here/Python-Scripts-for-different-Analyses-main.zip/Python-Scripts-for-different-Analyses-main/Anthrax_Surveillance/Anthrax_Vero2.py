import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Set Times New Roman globally
plt.rcParams["font.family"] = "Times New Roman"

# === Prepare Data ===
df = pd.DataFrame({
    "Date": [
        "26-Nov-23", "01-Dec-23", "06-Dec-23", "14-Dec-23", "18-Dec-23",
        "20-Dec-23", "22-Dec-23", "26-Dec-23", "27-Dec-23", "31-Dec-23",
        "06-Jan-24", "20-Jan-24", "08-Feb-24", "15-Feb-24", "29-Feb-24",
        "13-Mar-24", "17-Mar-24", "21-Mar-24", "28-Mar-24", "04-Jun-24",
        "10-Jun-24", "16-Jun-24", "16-Aug-24", "15-Sep-24", "16-Sep-24",
        "26-Sep-24", "27-Sep-24", "07-Oct-24", "08-Oct-24", "21-Oct-24",
        "31-Oct-24", "05-Nov-24", "06-Nov-24", "10-Nov-24", "15-Nov-24",
        "26-Nov-24", "04-Dec-24", "10-Dec-24", "13-Dec-24", "17-Dec-24",
        "20-Dec-24", "24-Dec-24", "09-Jan-25", "11-Jan-25", "20-Jan-25",
        "14-Feb-25", "28-Feb-25", "05-Mar-25", "30-Mar-25", "04-Apr-25",
        "10-Apr-25"
    ],
    "Cases": [
        3, 1, 3, 1, 2, 1, 2, 1, 1, 1,
        2, 1, 1, 3, 1, 2, 1, 4, 1, 1,
        2, 4, 2, 1, 2, 1, 2, 1, 1, 1,
        2, 2, 2, 3, 2, 1, 1, 3, 2, 4,
        8, 1, 2, 5, 2, 2, 2, 1, 1, 1,
        4
    ]
})
# === Data Prep ===
df["Date"] = pd.to_datetime(df["Date"], format="%d-%b-%y")
df["Month"] = df["Date"].dt.strftime("%b")
df["Month_Num"] = df["Date"].dt.month
df["Year"] = df["Date"].dt.year

# === Monthly Average Cases ===
monthly_avg = df.groupby(["Month_Num", "Month"])["Cases"].mean().reset_index()
monthly_avg = monthly_avg.sort_values("Month_Num")

# === Plot ===
plt.figure(figsize=(14, 6))
ax = plt.gca()  # Get the current axes object

# Barplot
sns.barplot(data=monthly_avg, x="Month", y="Cases", color="#199dba", label="Monthly Average", ax=ax)

# Trend Line
sns.lineplot(data=monthly_avg, x="Month", y="Cases", color="darkred", marker="o", linewidth=2.5, label="Trend", ax=ax)

# Customize X and Y-axis labels
ax.set_xlabel("", fontsize=14)
ax.set_xticklabels(monthly_avg["Month"], fontsize=18, rotation=-45)

# Customize Y-axis label and ticks
ax.set_ylabel("Average Cases", fontsize=18)

# Increase font size of Y-axis tick labels
ax.tick_params(axis='y', labelsize=16)

# Add grid, legend, and title
ax.grid(axis="y", linestyle="--", alpha=0.5)
ax.set_title("Monthly Average of Laboratory Confirmed Anthrax Cases in Uganda, (2023–2025)", fontsize=18, weight="bold")
ax.legend()

plt.tight_layout()
plt.show()
