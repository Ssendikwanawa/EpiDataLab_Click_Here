import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Prepare dataset
data = {
    "Date": ["03/02/2025", "05/02/2025", "06/02/2025", "07/02/2025", "08/02/2025", "09/02/2025", "10/02/2025",
             "11/02/2025", "12/02/2025", "13/02/2025", "14/02/2025", "15/02/2025", "16/02/2025", "17/02/2025",
             "18/02/2025", "19/02/2025", "20/02/2025", "21/02/2025", "22/02/2025", "23/02/2025", "24/02/2025",
             "25/02/2025"],
    "Number_of_Alerts": [6, 5, 3, 3, 5, 3, 2,
                         2, 4, 9, 15, 8, 9, 4,
                         2, 0, 0, 2, 1, 1, 1, 0],
    "intervention": ["Early Response Activities"] * 7 +
                    ["Ring Sweep Strategy"] * 7 +
                    ["Active Case Search"] * 8,
}

df = pd.DataFrame(data)
df["Date"] = pd.to_datetime(df["Date"], dayfirst=True)

# Aggregate total alerts per intervention
cumulative_by_intervention = df.groupby("intervention")["Number_of_Alerts"].sum().reset_index()

# Define desired order
order = ["Early Response Activities", "Ring Sweep Strategy", "Active Case Search"]

# Set plot style
sns.set(style="whitegrid")
fig, axes = plt.subplots(nrows=2, ncols=1, figsize=(14, 10), gridspec_kw={'height_ratios': [1.5, 1.2]})

# Plot A: Daily Alerts by Intervention (Line Plot)
sns.lineplot(data=df, x="Date", y="Number_of_Alerts", hue="intervention",
             marker="o", linewidth=3, ax=axes[0], palette={
                 "Early Response Activities": "#0073e6",
                 "Ring Sweep Strategy": "#00cc44",
                 "Active Case Search": "#ff3333"
             })
axes[0].set_title("Alerts by Intervention", fontsize=16, fontweight="bold")
axes[0].set_ylabel("Daily Alerts\nby Intervention", fontsize=14)
axes[0].set_xlabel("")
axes[0].tick_params(axis='x', labelrotation=-2)
axes[0].legend(title="Intervention Type", title_fontsize=14, fontsize=13)

# Plot B: Total Alerts by Intervention (Bar Plot) with specified order
bars=sns.barplot(data=cumulative_by_intervention,
            x="intervention", y="Number_of_Alerts", ax=axes[1],
            order=order,
            palette={
                "Early Response Activities": "#0073e6",
                "Ring Sweep Strategy": "#00cc44",
                "Active Case Search": "#ff3333"
            })
axes[1].set_title("", fontsize=18, fontweight="bold")
axes[1].set_ylabel("Total Alerts\nby Intervention", fontsize=14)
axes[1].set_xlabel("")
axes[1].tick_params(axis='x', labelrotation=0)

# Annotate values inside bars
for patch in bars.patches:
    height = patch.get_height()
    bars.annotate(f'{int(height)}',
                  xy=(patch.get_x() + patch.get_width() / 2, height / 2),
                  ha='center', va='center',
                  color='white', fontweight='bold', fontsize=14)

plt.tight_layout()
plt.show()
