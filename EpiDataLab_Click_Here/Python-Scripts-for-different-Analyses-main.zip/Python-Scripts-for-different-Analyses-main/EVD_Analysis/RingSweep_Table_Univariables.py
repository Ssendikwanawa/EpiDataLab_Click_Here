import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.table import Table

# Data
data = {
    "District": ["Mbale City"] * 8 + ["Soroti District"] * 2 + ["Over all"],
    "Sub\nCounty": [
        "Bukonde", "Industrial Division", "Lwasso", "Nakaloke T/C", "Namabasa",
        "Namanyonyi", "Northern Division", "Nakaloke S/C",
        "Buwasa", "Nalusala", "Over all"],
    "HH\nMembers\nGiven\nInfo": [4223, 9548, 2757, 11322, 17546, 10318, 3585, 14525, 1371, 834, 76029],
    "S/C\nPopulation": [15673, 51454, 29092, 34423, 37406, 34040, 59130, 42000, 10800, 6100, 320118],
    "Proportion_HH\nInfoGiven": [0.3, 0.2, 0.1, 0.3, 0.5, 0.3, 0.1, 0.4, 0.1, 0.1, 0.2],
    "HH\nVisited": [1275, 2508, 592, 2148, 2744, 2266, 922, 2075, 580, 139, 15249],
    "S/C\nHH\nNumber": [5676, 19149, 6430, 3247, 4109, 12096, 17909, 4773, 1638, 1793, 76820],
    "Proportion_HH\nVisited": [0.2, 0.1, 0.1, 0.7, 0.7, 0.2, 0.1, 0.4, 0.4, 0.1, 0.2]
}
df = pd.DataFrame(data)

# Display tweaks
df["Proportion_HH\nInfoGiven"] = df["Proportion_HH\nInfoGiven"].round(1)
df["Proportion_HH\nVisited"] = df[ "Proportion_HH\nVisited"].round(1)

# Plot setup
fig, ax = plt.subplots(figsize=(11, 6))
ax.axis("off")

# Table setup
table = Table(ax, bbox=[0, 0, 1, 1])
n_rows, n_cols = df.shape
row_height = 0.4
col_width = 0.2

# Colors
header_color = "#d9d9d9"
alt_row_colors = ["#ffffff", "#f4f4f4"]
highlight_color = "#cfe2f3"
highlight_cols = ["Proportion_HH\nInfoGiven", "Proportion_HH\nVisited"]

# Column headers
for i, col in enumerate(df.columns):
    table.add_cell(0, i, width=col_width * 0.95, height=row_height,
                   text=col, loc="center", facecolor=header_color,
                   fontproperties={'family': 'Times New Roman', 'weight': 'bold', 'size': 30})

# Data cells
for row in range(n_rows):
    for col in range(n_cols):
        val = df.iat[row, col]
        col_name = df.columns[col]
        color = alt_row_colors[row % 2]
        if col_name in highlight_cols and val >= 0.3:
            color = highlight_color
        table.add_cell(row + 1, col, width=col_width * 0.95, height=row_height,
                       text=val, loc="center", facecolor=color,
                       fontproperties={'size': 29})

# Add table
ax.add_table(table)

# Title
plt.title("Household Awareness and Visit Indicators During Ebola Response",
          fontsize=24, fontname="Times New Roman", pad=10)

# Footnote
plt.figtext(0.5, -0.2, "Note: HH = Household, S/C = Sub County",
            ha="center", fontsize=12, fontname="calibri", style="italic")

plt.tight_layout(pad=0.2)
plt.show()
