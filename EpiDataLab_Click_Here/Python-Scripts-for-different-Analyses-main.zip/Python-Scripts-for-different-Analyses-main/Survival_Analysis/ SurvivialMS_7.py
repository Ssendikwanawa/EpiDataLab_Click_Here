# === Required Libraries ===
import pandas as pd
import matplotlib.pyplot as plt
from lifelines import KaplanMeierFitter

# === Load and Clean Data ===
df = pd.read_csv(r"D:\EVD_Mbale\Mortality_Surveillance\Encoded_Mortality_Surveillance_Data.csv")

# Keep relevant variables and drop rows with NA or empty string in Sex
df = df[['time_to_event', 'Sample_collected', 'Sex_encoded', 'Death_outside_HomeDistrict']].dropna()
df = df[~df['Sex_encoded'].astype(str).str.strip().eq("")]

# Rename columns for clarity
df.rename(columns={
    'time_to_event': 'duration',
    'Sample_collected': 'event',
    'Sex_encoded': 'Sex',
    'Death_outside_HomeDistrict': 'DeathOutside'
}, inplace=True)

# Convert to string for grouping
df['Sex'] = df['Sex'].astype(str)
df['DeathOutside'] = df['DeathOutside'].astype(int).astype(str)  # to treat 0/1 as group labels

# === Plot Stratified Failure Curves ===
plt.figure(figsize=(10, 6))
kmf = KaplanMeierFitter()

# Stratify by both Sex and DeathOutside
for sex in df['Sex'].unique():
    for status in df['DeathOutside'].unique():
        label = f"Sex: {sex}, Died Outside: {status}"
        subgroup = df[(df['Sex'] == sex) & (df['DeathOutside'] == status)]
        if not subgroup.empty:
            kmf.fit(subgroup['duration'], event_observed=subgroup['event'], label=label)
            kmf.plot_cumulative_density(ci_show=True)

plt.title("Stratified Failure Curve by Sex and Death Location", fontweight="bold", fontsize=18)
plt.xlabel("Time (Days After Death)", fontsize=14)
plt.ylabel("Probability Sample Collected", fontsize=14)
plt.grid(True)
plt.legend(title="Group", fontsize=10)
plt.tight_layout()
plt.show()
