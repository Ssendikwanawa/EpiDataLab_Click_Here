import pandas as pd
import matplotlib.pyplot as plt
from lifelines import KaplanMeierFitter

# Load the cleaned dataset
df = pd.read_csv(r"D:\EVD_Mbale\Mortality_Surveillance\Encoded_Mortality_Surveillance_Data.csv")

# Keep relevant columns and drop missing/blank rows
df = df[['time_to_event', 'Sample_collected', 'Sex_encoded']].dropna()
df = df[~df['Sex_encoded'].astype(str).str.strip().eq("")]

# Rename for lifelines
df.rename(columns={
    'Sample_collected': 'event',
    'time_to_event': 'duration',
    'Sex_encoded': 'Sex'
}, inplace=True)

# Convert to string for labeling
df['Sex'] = df['Sex'].astype(str)

# Fit Kaplan-Meier estimator by sex group
kmf = KaplanMeierFitter()
plt.figure(figsize=(10, 6))

for sex_group in df['Sex'].unique():
    mask = df['Sex'] == sex_group
    kmf.fit(durations=df[mask]['duration'], event_observed=df[mask]['event'], label=f"Sex: {sex_group}")
    kmf.plot_cumulative_density(ci_show=True)

plt.title("Kaplan-Meier Failure Curve by Sex", fontsize=16, fontweight='bold')
plt.xlabel("Time (Days After Death)", fontsize=14)
plt.ylabel("Probability Sample Collected", fontsize=14)
plt.grid(True)
plt.tight_layout()
plt.show()
