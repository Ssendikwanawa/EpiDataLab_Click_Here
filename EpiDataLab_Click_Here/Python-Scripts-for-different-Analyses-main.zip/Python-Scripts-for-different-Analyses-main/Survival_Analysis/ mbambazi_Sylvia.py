# === Required Libraries ===
import pandas as pd
import matplotlib.pyplot as plt
from lifelines import KaplanMeierFitter, CoxPHFitter
from lifelines.statistics import proportional_hazard_test

# Load your dataset
df = pd.read_excel("D:/EVD_Mbale/Mortality_Surveillance/nEW_DR.MS_DATA.xlsx")


print(df.columns.tolist())

# Convert date columns to datetime
data['Date_of_Death'] = pd.to_datetime(data['Date_of_Death'], errors='coerce')
data['Date_of_sample_collection'] = pd.to_datetime(data['Date_of_sample_collection'], errors='coerce')

# Create time_to_event in days
data['time_to_event'] = (data['Date_of_sample_collection'] - data['Date_of_Death']).dt.days

# Drop rows with missing time or Sample_collected values
data = data.dropna(subset=['time_to_event', 'Sample_collected'])

# Ensure correct data types
data['Sample_collected'] = data['Sample_collected'].astype(int)
data['time_to_event'] = pd.to_numeric(data['time_to_event'], errors='coerce')



# Drop rows with missing or whitespace-only entries in key columns
df = df[['time_to_event', 'Sample_collected', 'Age',
         'District_encoded', 'Source_of_death_alert_encoded',
         'PlaceofdeathHF_LEVEL_encoded', 'Sex_encoded',
         'Death_outside_HomeDistrict']].dropna()

df = df[~df['Sex_encoded'].astype(str).str.strip().eq("")]  # Clean empty Sex values

# Rename for lifelines
df.rename(columns={
    'Sample_collected': 'event',
    'time_to_event': 'duration',
    'District_encoded': 'District',
    'Source_of_death_alert_encoded': 'Source_of_death_alert',
    'PlaceofdeathHF_LEVEL_encoded': 'PlaceofdeathHF_LEVEL',
    'Sex_encoded': 'Sex'
}, inplace=True)

# === Kaplan-Meier Failure Curve ===
kmf = KaplanMeierFitter()
kmf.fit(durations=df["duration"], event_observed=df["event"])

plt.figure(figsize=(8, 6))
kmf.plot_cumulative_density()
plt.title("Kaplan-Meier Failure Estimate", fontweight="bold", size=22)
plt.xlabel("Time (Days After Death)", fontweight="bold", size=18)
plt.ylabel("Probability Sample Collected", fontweight="bold", size=18)
plt.grid(True)
plt.tight_layout()
plt.show()

# === Cox Proportional Hazards Model ===
# Convert categorical columns to string
categorical_vars = ['District', 'Source_of_death_alert', 'PlaceofdeathHF_LEVEL', 'Sex']
for col in categorical_vars:
    df[col] = df[col].astype(str)

# One-hot encode categorical variables
df_encoded = pd.get_dummies(df, columns=categorical_vars, drop_first=True)

# Fit Cox Model
cph = CoxPHFitter()
cph.fit(df_encoded, duration_col='duration', event_col='event')

# Extract and rename key metrics
cox_summary = cph.summary[['exp(coef)', 'se(coef)', 'z', 'p', 'exp(coef) lower 95%', 'exp(coef) upper 95%']]
cox_summary.rename(columns={
    'exp(coef)': 'HR',
    'se(coef)': 'SE',
    'z': 'Z',
    'p': 'P-value',
    'exp(coef) lower 95%': 'CI Lower 95%',
    'exp(coef) upper 95%': 'CI Upper 95%'
}, inplace=True)

# Ensure full column display
pd.set_option('display.max_columns', None)

print("\nCox Model Results (HR, SE, Z, P-value, 95% CI):")
print(cox_summary)

# === Proportional Hazards Assumption Test ===
ph_results = proportional_hazard_test(cph, df_encoded, time_transform='rank')
ph_pvalues = ph_results.summary[['p']].rename(columns={'p': 'PH Test P-value'})

print("\nProportional Hazards Assumption Test P-values:")
print(ph_pvalues)
