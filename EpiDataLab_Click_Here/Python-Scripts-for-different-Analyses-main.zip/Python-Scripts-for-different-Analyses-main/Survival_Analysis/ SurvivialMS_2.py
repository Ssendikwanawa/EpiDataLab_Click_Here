# === Required Libraries ===
import pandas as pd
import matplotlib.pyplot as plt
from lifelines import KaplanMeierFitter, CoxPHFitter
from lifelines.statistics import proportional_hazard_test

# === Load and Clean Data ===
df = pd.read_csv(r"D:\EVD_Mbale\Mortality_Surveillance\Encoded_Mortality_Surveillance_Data.csv")

# Drop missing or empty whitespace rows in key columns
df = df[['time_to_event', 'Sample_collected', 'Age',
         'District_encoded', 'Source_of_death_alert_encoded',
         'PlaceofdeathHF_LEVEL_encoded', 'Sex_encoded',
         'Death_outside_HomeDistrict']].dropna()

df = df[~df['Sex_encoded'].astype(str).str.strip().eq("")]  # ensure Sex column has no blanks

# Rename for clarity
df.rename(columns={
    'Sample_collected': 'event',
    'time_to_event': 'duration',
    'District_encoded': 'District',
    'Source_of_death_alert_encoded': 'Source_of_death_alert',
    'PlaceofdeathHF_LEVEL_encoded': 'PlaceofdeathHF_LEVEL',
    'Sex_encoded': 'Sex'
}, inplace=True)

# Convert categoricals to strings
categorical_vars = ['District', 'Source_of_death_alert', 'PlaceofdeathHF_LEVEL', 'Sex']
df[categorical_vars] = df[categorical_vars].astype(str)

# One-hot encode
df_encoded = pd.get_dummies(df, columns=categorical_vars, drop_first=True)

# === Kaplan-Meier Failure Curve ===
kmf = KaplanMeierFitter()
kmf.fit(df["duration"], event_observed=df["event"])

plt.figure(figsize=(8, 6))
kmf.plot_cumulative_density()
plt.title("Kaplan-Meier Failure Estimate", fontweight="bold", fontsize=20)
plt.xlabel("Time (Days After Death)", fontsize=16)
plt.ylabel("Probability Sample Collected", fontsize=16)
plt.grid(True)
plt.tight_layout()
plt.show()

# === Cox Proportional Hazards Model ===
cph = CoxPHFitter()
cph.fit(df_encoded, duration_col='duration', event_col='event')

# Extract and rename important metrics
cox_summary = cph.summary[['exp(coef)', 'se(coef)', 'z', 'p', 'exp(coef) lower 95%', 'exp(coef) upper 95%']]
cox_summary.rename(columns={
    'exp(coef)': 'HR',
    'se(coef)': 'SE',
    'z': 'Z',
    'p': 'P-value',
    'exp(coef) lower 95%': 'CI Lower 95%',
    'exp(coef) upper 95%': 'CI Upper 95%'
}, inplace=True)

pd.set_option('display.max_columns', None)
print("\nCox Model Results (HR, SE, Z, P-value, 95% CI):")
print(cox_summary)

# === Proportional Hazards Assumption Test ===
ph_results = proportional_hazard_test(cph, df_encoded, time_transform='rank')
ph_pvals = ph_results.summary[['p']].rename(columns={'p': 'PH Test P-value'})

print("\nProportional Hazards Assumption Test P-values:")
print(ph_pvals)


