# === Required Libraries ===
import pandas as pd
from lifelines.statistics import logrank_test

# === Load and Clean Data ===
df = pd.read_csv(r"D:\EVD_Mbale\Mortality_Surveillance\Encoded_Mortality_Surveillance_Data.csv")

# Drop rows with missing or whitespace-only values in key columns
df = df[['time_to_event', 'Sample_collected', 'Sex_encoded']].dropna()
df = df[~df['Sex_encoded'].astype(str).str.strip().eq("")]

# Rename columns
df.rename(columns={
    'time_to_event': 'duration',
    'Sample_collected': 'event',
    'Sex_encoded': 'Sex'
}, inplace=True)

# Ensure Sex is string
df["Sex"] = df["Sex"].astype(str)

# === Log-Rank Test: Female vs Male ===
df_f = df[df["Sex"].str.lower() == "female"]
df_m = df[df["Sex"].str.lower() == "male"]

results = logrank_test(
    df_f["duration"], df_m["duration"],
    event_observed_A=df_f["event"],
    event_observed_B=df_m["event"]
)

print("=== Log-Rank Test: Female vs Male ===")
results.print_summary()
