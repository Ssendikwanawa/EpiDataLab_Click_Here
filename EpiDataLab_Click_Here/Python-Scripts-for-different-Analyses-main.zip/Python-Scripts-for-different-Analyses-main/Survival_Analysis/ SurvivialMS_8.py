import pandas as pd
from lifelines import CoxPHFitter

# === Load and Clean Data ===
df = pd.read_csv(r"D:\EVD_Mbale\Mortality_Surveillance\Encoded_Mortality_Surveillance_Data.csv")
df = df[['time_to_event', 'Sample_collected', 'Age',
         'District_encoded', 'Source_of_death_alert_encoded',
         'PlaceofdeathHF_LEVEL_encoded', 'Sex_encoded',
         'Death_outside_HomeDistrict']].dropna()
df = df[~df['Sex_encoded'].astype(str).str.strip().eq("")]

# Rename columns
df.rename(columns={
    'time_to_event': 'duration',
    'Sample_collected': 'event',
    'District_encoded': 'District',
    'Source_of_death_alert_encoded': 'Source_of_death_alert',
    'PlaceofdeathHF_LEVEL_encoded': 'PlaceofdeathHF_LEVEL',
    'Sex_encoded': 'Sex'
}, inplace=True)

# Convert categorical variables to string
categorical_vars = ['District', 'Source_of_death_alert', 'PlaceofdeathHF_LEVEL']
df[categorical_vars] = df[categorical_vars].astype(str)

# === Run Cox Model for each Sex separately ===
for sex in df['Sex'].unique():
    print(f"\n--- Cox Model for Sex: {sex} ---")
    subgroup = df[df['Sex'] == sex]
    df_encoded = pd.get_dummies(subgroup.drop(columns=['Sex']), columns=categorical_vars, drop_first=True)

    if df_encoded.shape[1] > 2:  # ensure we have more than just duration and event
        cph = CoxPHFitter()
        cph.fit(df_encoded, duration_col='duration', event_col='event')
        result = cph.summary[['exp(coef)', 'se(coef)', 'z', 'p', 'exp(coef) lower 95%', 'exp(coef) upper 95%']]
        result.rename(columns={
            'exp(coef)': 'HR',
            'se(coef)': 'SE',
            'z': 'Z',
            'p': 'P-value',
            'exp(coef) lower 95%': 'CI Lower 95%',
            'exp(coef) upper 95%': 'CI Upper 95%'
        }, inplace=True)
        print(result)
