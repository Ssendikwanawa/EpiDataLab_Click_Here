# === Required Libraries ===
import pandas as pd
import matplotlib.pyplot as plt
from lifelines import KaplanMeierFitter

# === Load and Clean Data ===
df = pd.read_csv(r"D:\EVD_Mbale\Mortality_Surveillance\Encoded_Mortality_Surveillance_Data.csv")

# Keep only relevant variables and drop missing
df = df[['time_to_event', 'Sample_collected', 'Sex_encoded']].dropna()
df = df[~df['Sex_encoded'].astype(str).str.strip().eq("")]  # remove empty strings

# Rename for clarity
df.rename(columns={
    'time_to_event': 'duration',
    'Sample_collected': 'event',
    'Sex_encoded': 'Sex'
}, inplace=True)

# Ensure Sex is string type
df['Sex'] = df['Sex'].astype(str)

# === Plot Stratified Failure Curves by Sex ===
plt.figure(figsize=(9, 6))
kmf = KaplanMeierFitter()

for sex_group in df['Sex'].unique():
    subset = df[df['Sex'] == sex_group]
    kmf.fit(subset['duration'], event_observed=subset['event'], label=f"Sex: {sex_group}")
    kmf.plot_cumulative_density(ci_show=True)  # Failure function = 1 - survival

plt.title("Stratified Failure Curve by Sex", fontweight="bold", fontsize=20)
plt.xlabel("Time (Days After Death)", fontsize=16)
plt.ylabel("Probability Sample Collected", fontsize=16)
plt.grid(True)
plt.legend(title="Sex", fontsize=12)
plt.tight_layout()
plt.show()
