# === Required Libraries ===
import pandas as pd
import matplotlib.pyplot as plt
from lifelines import CoxPHFitter
from lifelines.statistics import proportional_hazard_test

# === Load and Clean Data ===
df = pd.read_csv(r"D:\EVD_Mbale\Mortality_Surveillance\Encoded_Mortality_Surveillance_Data.csv")

# Drop missing or whitespace-only entries in key columns
df = df[['time_to_event', 'Sample_collected', 'Age',
         'District_encoded', 'Source_of_death_alert_encoded',
         'PlaceofdeathHF_LEVEL_encoded', 'Sex_encoded',
         'Death_outside_HomeDistrict']].dropna()

df = df[~df['Sex_encoded'].astype(str).str.strip().eq("")]  # Clean empty Sex values

# Rename for lifelines
df.rename(columns={
    'Sample_collected': 'event',
    'time_to_event': 'duration',
    'District_encoded': 'District',
    'Source_of_death_alert_encoded': 'Source_of_death_alert',
    'PlaceofdeathHF_LEVEL_encoded': 'PlaceofdeathHF_LEVEL',
    'Sex_encoded': 'Sex'
}, inplace=True)

# Convert categorical columns to string
categorical_vars = ['District', 'Source_of_death_alert', 'PlaceofdeathHF_LEVEL']
for col in categorical_vars:
    df[col] = df[col].astype(str)

# One-hot encode categorical variables (not stratifying ones)
df_encoded = pd.get_dummies(df, columns=categorical_vars, drop_first=True)

# === Stratified Cox Model ===
cph = CoxPHFitter()
cph.fit(df_encoded, duration_col='duration', event_col='event',
        strata=['Sex', 'Death_outside_HomeDistrict'])

# === Extract Key Results ===
cox_summary = cph.summary[['exp(coef)', 'se(coef)', 'z', 'p', 'exp(coef) lower 95%', 'exp(coef) upper 95%']]
cox_summary.rename(columns={
    'exp(coef)': 'HR',
    'se(coef)': 'SE',
    'z': 'Z',
    'p': 'P-value',
    'exp(coef) lower 95%': 'CI Lower 95%',
    'exp(coef) upper 95%': 'CI Upper 95%'
}, inplace=True)

print("\nStratified Cox Model Results (HR, SE, Z, P-value, 95% CI):")
print(cox_summary)

# === Proportional Hazards Assumption Test ===
ph_results = proportional_hazard_test(cph, df_encoded, time_transform='rank')
ph_pvalues = ph_results.summary[['p']].rename(columns={'p': 'PH Test P-value'})

print("\nPH Assumption Test (P-values):")
print(ph_pvalues)
